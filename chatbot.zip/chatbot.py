import math
import re
import decimal
import csv
import datetime
from collections import Counter

WORD = re.compile(r"\w+")

# cosine similarity algorithm

def get_cosine(vec1, vec2):
    intersection = set(vec1.keys()) & set(vec2.keys())
    numerator = sum([vec1[x] * vec2[x] for x in intersection])

    sum1 = sum([vec1[x] ** 2 for x in list(vec1.keys())])
    sum2 = sum([vec2[x] ** 2 for x in list(vec2.keys())])
    denominator = math.sqrt(sum1) * math.sqrt(sum2)

    if not denominator:
        return 0.0
    else:
        return float(numerator) / denominator


def text_to_vector(text):
    words = WORD.findall(text)
    return Counter(words)

# info

print("Welcome To This Chatbot. type \"exit\" to end the application")
print("Made by Muhammad Bahar\n")

while True:
    user_input = str(input("[USER]: ")).lower()

    if user_input == "exit":
        quit(0)
    
    """
    text1 = "How are you today"
    text2 = "How are you doing"
    """

    data = list(csv.reader(open("chatbot_data.csv")))

    high_similiar_value = 0

    for x in range(len(data)):

        text2 = data[x][0]
        
        
        vector1 = text_to_vector(user_input)
        vector2 = text_to_vector(text2.lower())

        similar_value = get_cosine(vector1, vector2)
        similar_value = similar_value * 100
        similar_value = decimal.Decimal(similar_value)
        similar_value = round(similar_value,0)

        if similar_value > high_similiar_value:
            high_similiar_value = similar_value
            ai_answer_int = x

        else:
            pass

    
    ans = (data[ai_answer_int][1])

    try:
        exec(ans)
        
    except:
        pass
    
    print("[BOT]:",ans)



